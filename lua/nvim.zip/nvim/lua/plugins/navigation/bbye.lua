return {
    'moll/vim-bbye',
    lazy = false,
}
