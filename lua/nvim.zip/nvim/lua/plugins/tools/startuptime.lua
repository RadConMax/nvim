return {
    'dstein64/vim-startuptime',
    lazy = false,
}
